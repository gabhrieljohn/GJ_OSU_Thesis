#Set time zone
Sys.setenv(TZ = 'PST')

#Source needed functions
source('~/rscripts/HJA/discovery_tree/screening_2023-03-28/screening_functions.r')

#Load data
load('~/data/HJA/discovery_tree/screening_2023-03-28/dt_and_flag_screening_v1.Rdat')

#Make dat, flag and ts global
dat <<- dat
flag <<- flag
#ts <<- ts

#Make decisions
#--------------------------------------------------------------#
#Wind Speed and direction: Get rid of one time period @ 56m where the sensor flatlined at zero 
badID = which(ts == '2020-12-28 12:00:00'):which(ts == '2021-02-24 15:20:00')
plot(dat$WSPD_SNC_MEAN_5600_0_01[badID],x = ts[badID])

dat$WSPD_SNC_MEAN_5600_0_01[badID] = NA
flag$WSPD_SNC_MEAN_5600_0_01[badID] = 'R'
#--------------------------------------------------------------#


#WRITE OUT THE  SCREENED DATA
save(list = c('dat','flag','ts'),file = '~/data/HJA/discovery_tree/screening_2023-03-28/dt_and_flag_screening_v2.Rdat')





