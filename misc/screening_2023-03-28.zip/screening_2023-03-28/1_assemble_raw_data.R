#main directory where data resides
#maindir = '~/data/discovery_tree/'
#fundir = '~/rscripts/discovery_tree/fun/'
maindir = '/md1/data/HJA/discovery_tree/'
fundir = '/md1/rscripts/HJA/discovery_tree/fun/'
library('dplyr')

#Set the timezone
Sys.setenv(TZ='PST')

#FUNCTIONS
source(paste(fundir,'climreadHJA.r',sep=''))
source(paste(fundir,'assembleHJA.r',sep=''))


#FIRST, ASSEMBLE DISCOVERY TREE
########################################################################################################################
#keyword in the names of the climate files in the "new" directory which marks the file as containing the data of interest.
akey = 'dscmet_420_a_'
bkey = 'dscmet_420_b_'
ckey = 'dscmet_421_a_'
dkey = 'dscmet_421_b_'

keylist = list(akey,bkey,ckey,dkey)

#VARIABLE NAMES IN RAW AND SCREENED FILES
#------------------------------------------------------------------------------#
vnames = read.csv('/md1/data/HJA/discovery_tree/varnames_2023-03-28.csv',colClasses = 'character')

#Get just the original column,add flag_ columns
vnames = data.frame(original = c(vnames$original,paste0('Flag_',vnames$original)))
#------------------------------------------------------------------------------#

#Read in all the data
#--------------------------------------------------------------------------------------------------------#
newlist = list()

for(i in 1:length(keylist)){
  
  key = paste('*',keylist[[i]],'*',sep='')
  newstuff = list.files(path = paste(maindir,'raw_2023-03-27',sep=''),pattern = key,full.names = T,recursive = T)
  newstuff_names = list.files(path = paste(maindir,'raw_2023-03-27',sep=''),pattern = key,full.names = F,recursive = T)
  
  newlist.i = list()
  
  for(j in 1:length(newstuff)){
    x = read.table(newstuff[j],sep = ',', skip = 5, header = F, stringsAsFactors = F)
    colnames(x) = as.character(as.matrix(read.table(newstuff[j], sep = ',', skip = 2, nrows = 1, header = F)))
    x$Date = as.POSIXct(x$Date)
    newlist.i[[j]] = x
  }
  names(newlist.i) = newstuff_names
  newlist[[i]] = newlist.i
  names(newlist)[[i]] = keylist[[i]]
  
}
#--------------------------------------------------------------------------------------------------------#

#Running the assemble function
#-------------------------------------------------------#
discovery = assembleHJA(newlist = newlist,vnames,vname_type = 'original',drange = NULL)
drange = c(as.POSIXct("2018-12-06 00:00:00 PST"),as.POSIXct('2023-03-15 00:00:00 PST'))
discovery = discovery[which(discovery$timestamp == drange[1]):which(discovery$timestamp == drange[2]),]
#apply(discovery,2,function(x){length(which(is.na(x)))})*100/nrow(discovery)
#-------------------------------------------------------#

#Split discovery into "discovery" and "flags"
flag = discovery[,grep('Flag',colnames(discovery))]
ts = discovery$timestamp
dat = discovery[,2:37]

#Save it out
save(list = c('ts','dat','flag'),file = '/md1/data/HJA/discovery_tree/screening_2023-03-28/dt_and_flag_screening_v0.Rdat')



