#Set time zone
Sys.setenv(TZ = 'PST')

#Write directory
writedir = '~/data/HJA/discovery_tree/screening_2023-03-28/official_repo/'

#The data
#-------------------------------------------------------------------------------#
load('~/data/HJA/discovery_tree/screening_2023-03-28/dt_and_flag_screening_v2.Rdat')

#Cut it down to just 2018-12-05 23:55:00 (night before 56m sensor failure)
# cutID = which(ts == '2018-12-05 23:55:00')
# dat = dat[1:cutID,]
# flag = flag[1:cutID,]
# ts = ts[1:cutID]

uflag = unique(unlist(apply(flag,2,unique)))

#Simplify flags. I and V go to Q. R goes to M. N goes to A. 
flag[which(flag == 'R',arr.ind = T)] = 'M'
#flag[which(flag == 'I',arr.ind = T)] = 'Q'
flag[which(flag == 'V',arr.ind = T)] = 'Q'
flag[which(flag == 'N',arr.ind = T)] = 'A'

#If any data is NA for any reason, make the flag "M"
naID = which(is.na(dat),arr.ind=T)
dim(naID)
flag[naID] = 'M'


uflag = unique(unlist(apply(flag,2,unique)))
#-------------------------------------------------------------------------------#

#Variables names in raw and screened files
vnames = read.csv('~/data/HJA/discovery_tree/screening_2023-03-28/varnames_dscmet_individualize.csv',colClasses = 'character')

#epuller1 function: sticks all vars from an entity together
epuller1 = function(entity){
  
  vlist = list()
  
  loopID = which(vnames$ENTITY == entity) 

  for(i in 1:length(loopID)){
  
    vi = vnames[loopID[i],]
  
    idat = dat[which(colnames(dat) == vi$all)]
  
    #Remove any leading or trailing NAs
    if(is.na(idat[1,])){
      x = rle(is.na(as.numeric(as.matrix((idat)))))
      ID1 = x$lengths[1]+1
    }else{ID1 = 1}
    if(is.na(tail(idat[,1],1))){
      x = rle(is.na(as.numeric(as.matrix((idat)))))
      ID2 = nrow(idat) - tail(x$lengths,1)
    }else{ID2 = nrow(idat)}
    ID = ID1:ID2
  
    #Create the DBCODE, ENTITY, PROBE_CODE
    DBCODE = rep(vi$DBCODE,length(ID))
    ENTITY = rep(entity,length(ID))
    PROBE_CODE = rep(vi$PROBE_CODE,length(ID))
    SITECODE = rep(vi$SITECODE,length(ID))
  
    #Pull out the variable and flag
    VARI = dat[ID,which(colnames(dat) == vi$all)]
    FLAGI = flag[ID,which(colnames(flag) == vi$all)]
    DATE_TIME = ts[ID]
  
    #Make the Dataframe
    dfi = data.frame(DBCODE = DBCODE, SITECODE = SITECODE, ENTITY = ENTITY, PROBE_CODE = PROBE_CODE,DATE_TIME = DATE_TIME, VARI = VARI, FLAGI = FLAGI)
  
    colnames(dfi)[6] = vi$VARNAME
    colnames(dfi)[7] = vi$FLAGNAME
    
    vlist[[i]] = dfi
  }  

  out = do.call('rbind',vlist)
  out = out[order(out$DATE_TIME,out$PROBE_CODE),]
  
  print(vi$VARNAME)
  print(vi$FLAGNAME)
  print(paste0('First record ',min(out$DATE_TIME)))
  print(paste0('Last record ',max(out$DATE_TIME)))
  
  print(paste0('Minimum value ',min(out[,6],na.rm=T)))
  print(paste0('Maxiumum value ',max(out[,6],na.rm=T)))
  
  return(out)
}

#epuller2 function: sticks all vars from an entity together when the entity has ....something?..... probe codes
epuller2 = function(entity){
  
  vlist = list()
  
  vnames1 = vnames[which(vnames$ENTITY == entity),] 
  
  probes = unique(vnames1$PROBE_CODE)
  
  for(i in 1:length(probes)){
    
    vi = vnames1[which(vnames1$PROBE_CODE == probes[i]),]
    
    idat = dat[,match(vi$all, colnames(dat))]
    
    #Remove any leading or trailing NAs
    natester = apply(idat,1,FUN = function(x){all(is.na(x))})
    if(natester[1] == T){
      x = rle(natester)
      ID1 = x$lengths[1]+1
    }else{ID1 = 1}
    if(tail(natester,1) == T){
      x = rle(natester)
      ID2 = nrow(idat) - tail(x$lengths,1)
    }else{ID2 = nrow(idat)}
    ID = ID1:ID2
    
    #Create the DBCODE, ENTITY, PROBE_CODE
    DBCODE = rep(vi$DBCODE[1],length(ID))
    ENTITY = rep(entity,length(ID))
    PROBE_CODE = rep(vi$PROBE_CODE[1],length(ID))
    SITECODE = rep(vi$SITECODE[1],length(ID))
    
    #Pull out the variable and flag
    VARI = dat[ID,match(vi$all,colnames(dat))]
    FLAGI = flag[ID,match(vi$all,colnames(flag))]
    DATE_TIME = ts[ID]
    
    #Make the Dataframe
    dfi = data.frame(DBCODE = DBCODE, SITECODE = SITECODE, ENTITY = ENTITY, PROBE_CODE = PROBE_CODE,DATE_TIME = DATE_TIME, VARI = VARI, FLAGI = FLAGI)
    
    colnames(dfi)[6:(5+nrow(vi))] = vi$VARNAME
    colnames(dfi)[(6+nrow(vi)):(5+nrow(vi)+nrow(vi))] = vi$FLAGNAME
    
    vlist[[i]] = dfi
  }  
  
  out = do.call('rbind',vlist)
  out = out[order(out$DATE_TIME,out$PROBE_CODE),]
  
  print(vi$VARNAME)
  print(vi$FLAGNAME)
  print(paste0('First record ',min(out$DATE_TIME)))
  print(paste0('Last record ',max(out$DATE_TIME)))
  
  #print(paste0('Minimum value ',min(out[,6],na.rm=T)))
  #print(paste0('Maxiumum value ',max(out[,6],na.rm=T)))
  
  return(out)
}

#Entity 1: Air temperature
ent = 1
e1 = epuller1(ent)  
write.csv(e1,file = paste0(writedir,vnames$FILENAME[which(vnames$ENTITY == ent)[1]],'.csv'),na = 'NULL',row.names=F, quote = F)
  
#Entity 2: Dewpoint temperature
ent = 2
e2 = epuller1(ent)  
write.csv(e2,file = paste0(writedir,vnames$FILENAME[which(vnames$ENTITY == ent)[1]],'.csv'),na = 'NULL',row.names=F, quote = F)

#Entity 3: Relative Humidity
ent = 3
e3 = epuller1(ent)  
write.csv(e3,file = paste0(writedir,vnames$FILENAME[which(vnames$ENTITY == ent)[1]],'.csv'),na = 'NULL',row.names=F, quote = F)

#Entity 4: Saturated vapor pressure
ent = 4
e4 = epuller2(ent)  
write.csv(e4,file = paste0(writedir,vnames$FILENAME[which(vnames$ENTITY == ent)[1]],'.csv'),na = 'NULL',row.names=F, quote = F)

#Entity 5: Vapor pressure deficit
ent = 5
e5 = epuller1(ent)  
write.csv(e5,file = paste0(writedir,vnames$FILENAME[which(vnames$ENTITY == ent)[1]],'.csv'),na = 'NULL',row.names=F, quote = F)

#Entity 6: Leaf Wetness
ent = 6
e6 = epuller1(ent)  
write.csv(e6,file = paste0(writedir,vnames$FILENAME[which(vnames$ENTITY == ent)[1]],'.csv'),na = 'NULL',row.names=F, quote = F)

#Entity 7: Wind stuff
ent = 7
e7 = epuller2(ent)  
write.csv(e7,file = paste0(writedir,vnames$FILENAME[which(vnames$ENTITY == ent)[1]],'.csv'),na = 'NULL',row.names=F, quote = F)

#Entity 8: Soil temperature
ent = 8
e8 = epuller1(ent)  
write.csv(e8,file = paste0(writedir,vnames$FILENAME[which(vnames$ENTITY == ent)[1]],'.csv'),na = 'NULL',row.names=F, quote = F)

#Entity 9: Soil water content
ent = 9
e9 = epuller1(ent)  
write.csv(e9,file = paste0(writedir,vnames$FILENAME[which(vnames$ENTITY == ent)[1]],'.csv'),na = 'NULL',row.names=F, quote = F)

#Done!



# OLD STUFF
# #Set the time zone
# Sys.setenv(TZ = 'PST')
# 
# #Data
# load('~/data/HJA/discovery_tree/screening_2023-03-28/dt_and_flag_screening_v2.Rdat')
# 
# #Checking the case mentioned
# checkID = which(ts == '2019-01-03 10:10')
# 
# dat[checkID,]
# flag[checkID,]
# 
# #Check Airtemp 
# airdsc = read.csv('/md1/data/HJA/discovery_tree/screening_2023-03-28/official_repo/AIRDSC.csv')
# checkID2 = which(airdsc$DATE_TIME == '2019-01-03 10:10:00')
# airdsc[checkID2,]
# 
# #Check Dewpt
# dewdsc = read.csv('/md1/data/HJA/discovery_tree/screening_2023-03-28/official_repo/DEWDSC.csv')
# 
# checkID2 = which(dewdsc$DATE_TIME == '2019-01-03 10:10:00')
# dewdsc[checkID2,]
