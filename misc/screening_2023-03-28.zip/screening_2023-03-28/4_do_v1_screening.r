#Set time zone
Sys.setenv(TZ = 'PST')

#Source needed functions
source('~/rscripts/HJA/discovery_tree/screening_2023-03-28/screening_functions.r')

#Load data
load('~/data/HJA/discovery_tree/screening_2023-03-28/dt_and_flag_screening_v0.1.Rdat')

#Make dat, flag and ts global
dat <<- dat
flag <<- flag
#ts <<- ts

#OK, Implement the decisions from looking at the screening plots
#screenboi = function(dat = dat, flag = flag, ts = ts, vars = vars, derivs = NULL, from, to, badflag = NULL, goodrange = NULL)
#--------------------------------------------------------------#
#Soil temperature: accept all error flags at all depths
badflag = c('I','Q')
goodrange = NULL
vars = c("SOILTEMP_MEAN_0_10_01","SOILTEMP_MEAN_0_20_01","SOILTEMP_MEAN_0_50_01","SOILTEMP_MEAN_0_100_01")
from = ts[1]
to = tail(ts,1)
screenboi(badflag = badflag, from = from, to = to)

#Soil water content: accept all Impossible flags. Leave Questionable flags for now
badflag = c('I','Q')
goodrange = NULL
vars = c("SOILWC_MEAN_0_10_01","SOILWC_MEAN_0_20_01","SOILWC_MEAN_0_50_01","SOILWC_MEAN_0_100_01")
from = ts[1]
to = tail(ts,1)
screenboi(badflag = badflag, from = from, to = to)

#Radiation: Accept all flags. It is only necessary to do the shortwave in - no flags in other components
# badflag = c('I','Q')
# goodrange = NULL
# vars = 'p.swin'
# from = ts[1]
# to = tail(ts,1)
# screenboi(badflag = badflag, from = from, to = to)

#Wind Speed and direction: Accept all flags for wind speed. Leave wind direction alone. 
badflag = c('I','Q')
goodrange = NULL
vars = c("WSPD_SNC_MEAN_150_0_01","WSPD_SNC_MEAN_5600_0_01")
from = ts[1]
to = tail(ts,1)
screenboi(badflag = badflag, from = from, to = to)

#Atmospheric pressure: Accept all flags 
# badflag = c('I','Q')
# goodrange = NULL
# vars = 'p.atmpress'
# from = ts[1]
# to = tail(ts,1)
# screenboi(badflag = badflag, from = from, to = to)

#Air temperature: accept all error flags at all levels up until 2018-06-19. after that, must evaluate further. 
badflag = c('I','Q')
goodrange = NULL
vars = c("AIRTEMP_MEAN_150_0_01","AIRTEMP_MEAN_1000_0_01","AIRTEMP_MEAN_2000_0_01","AIRTEMP_MEAN_3000_0_01","AIRTEMP_MEAN_4000_0_01","AIRTEMP_MEAN_5600_0_01")
from = ts[1]
to = tail(ts,1)
screenboi(badflag = badflag, from = from, to = to)

#Accept all LW, precip and RH flags
badflag = c('I','Q')
goodrange = NULL
vars = c("LW_MEAN_150_0_01","LW_MEAN_1000_0_01","LW_MEAN_2000_0_01","LW_MEAN_3000_0_01","LW_MEAN_4000_0_01","LW_MEAN_5600_0_01","RELHUM_MEAN_150_0_01","RELHUM_MEAN_5600_0_01")
from = ts[1]
to = tail(ts,1)
screenboi(badflag = badflag, from = from, to = to)


#Use the "R" flag to remove any values that were dependent on one of the screened fundamental values above.
#Dependencies are built into the remove.dependent function. Look at that function in "discovery_tree_functions.r" 
#To see what the dependendices are. 
remove.dependent()

#WRITE OUT THE  SCREENED DATA
save(list = c('dat','flag','ts'),file = '~/data/HJA/discovery_tree/screening_2023-03-28/dt_and_flag_screening_v1.Rdat')





