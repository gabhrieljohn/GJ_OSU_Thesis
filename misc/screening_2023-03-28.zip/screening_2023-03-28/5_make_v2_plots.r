#Set the time zone
Sys.setenv(TZ = 'PST')

#Data
load('~/data/HJA/discovery_tree/screening_2023-03-28/dt_and_flag_screening_v1.Rdat')

#Necessary functions
source('~/rscripts/HJA/discovery_tree/screening_2023-03-28/screening_functions.r')

#Where to write out the plots
writedir = '~/data/HJA/discovery_tree/screening_2023-03-28/plots_v2/'
if(!file.exists(paste0(writedir,'LW_RH'))){system(paste0('mkdir ',writedir,'LW_RH'))}
if(!file.exists(paste0(writedir,'TAIR'))){system(paste0('mkdir ',writedir,'TAIR'))}
if(!file.exists(paste0(writedir,'TSOIL'))){system(paste0('mkdir ',writedir,'TSOIL'))}
if(!file.exists(paste0(writedir,'WCSOIL'))){system(paste0('mkdir ',writedir,'WCSOIL'))}
if(!file.exists(paste0(writedir,'WIND'))){system(paste0('mkdir ',writedir,'WIND'))}


#PLOTS
#-------------------------------------------------------#
#Dates to loop through
xbounds = seq(as.POSIXct(substr(ts[1],1,10)),as.POSIXct(substr(tail(ts,1),1,10)),by = 60*60*24*14)

#Loop through plots
for(i in 1:(length(xbounds)-1)){
  
  tsi = timepull(start = xbounds[i],stop = xbounds[i+1],x = ts,ts = ts)   
  dati = timepull(start = xbounds[i],stop = xbounds[i+1],x = dat,ts = ts)  
  flagi = timepull(start = xbounds[i],stop = xbounds[i+1],x = flag,ts = ts) 
  
  #LEAFWETNESS, RELATIVE HUMIDITY
  #............................................#
  {
    datlist = list(lw = dati[,c("LW_MEAN_150_0_01","LW_MEAN_1000_0_01","LW_MEAN_2000_0_01","LW_MEAN_3000_0_01","LW_MEAN_4000_0_01","LW_MEAN_5600_0_01")],
                   rh = dati[,c("RELHUM_MEAN_150_0_01","RELHUM_MEAN_5600_0_01")])
    
    flaglist = list(lw = flagi[,c("LW_MEAN_150_0_01","LW_MEAN_1000_0_01","LW_MEAN_2000_0_01","LW_MEAN_3000_0_01","LW_MEAN_4000_0_01","LW_MEAN_5600_0_01")],
                    rh = flagi[,c("RELHUM_MEAN_150_0_01","RELHUM_MEAN_5600_0_01")])
    
    collist = list(lwcol = heightcols,
                   rhcol = c(heightcols[c('0150','5600')],'yellow','purple'))
    
    ylabs = list(lw = 'Leaf wetness (mV)',rh = 'Relative Humidity (%)')
    
    flagplots(datlist = datlist,flaglist = flaglist,start = NULL,stop = NULL,plotcols = collist,
              xvar = tsi,ylabs = ylabs,
              plotname = paste0(writedir,'LW_RH/LW_RH',xbounds[i],'.jpeg'))
  }
  #............................................#
  
  #TEMPERATURE
  #............................................#
  {
    datlist = list(tair = dati[,c("AIRTEMP_MEAN_150_0_01","AIRTEMP_MEAN_1000_0_01","AIRTEMP_MEAN_2000_0_01","AIRTEMP_MEAN_3000_0_01","AIRTEMP_MEAN_4000_0_01","AIRTEMP_MEAN_5600_0_01")]
    )
    
    flaglist = list(tair = flagi[,c("AIRTEMP_MEAN_150_0_01","AIRTEMP_MEAN_1000_0_01","AIRTEMP_MEAN_2000_0_01","AIRTEMP_MEAN_3000_0_01","AIRTEMP_MEAN_4000_0_01","AIRTEMP_MEAN_5600_0_01")]
    )
    
    collist = list(taircol = heightcols)
    
    ylabs = list(tair = 'Air Temperature (deg C)',ptair = 'Air Temperature (deg C)')
    
    flagplots(datlist = datlist,flaglist = flaglist,start = NULL,stop = NULL,plotcols = collist,
              xvar = tsi,ylabs = ylabs,
              plotname = paste0(writedir,'TAIR/TAIR_',xbounds[i],'.jpeg'))
  }
  #............................................#
  
  #WIND DIRECTION
  #............................................#
  {
    datlist = list(X1 = dati[,c("WSPD_SNC_MEAN_150_0_01","WSPD_SNC_MEAN_5600_0_01")],
                   X2 = dati[,c("WDIR_SNC_MEAN_150_0_01","WDIR_SNC_MEAN_5600_0_01")])
    
    flaglist = list(X1 = flagi[,c("WSPD_SNC_MEAN_150_0_01","WSPD_SNC_MEAN_5600_0_01")],
                    X2 = flagi[,c("WDIR_SNC_MEAN_150_0_01","WDIR_SNC_MEAN_5600_0_01")])
    
    collist = list(C1 = c('yellow',heightcols[c('0150','5600')]),
                   C2 = c('yellow',heightcols[c('0150','5600')]))
    
    ylabs = list(X1 = 'Wind speed (m/s)', X2 = 'Wind Direction')
    
    flagplots(datlist = datlist,flaglist = flaglist,start = NULL,stop = NULL,plotcols = collist,
              xvar = tsi,ylabs = ylabs,
              plotname = paste0(writedir,'WIND/WIND_',xbounds[i],'.jpeg'))
  }
  #............................................#
  
  #SOIL TEMPERATURE, 1.5M AIR TEMPERATURE
  #............................................#
  {
    cols1 = c("SOILTEMP_MEAN_0_10_01","SOILTEMP_MEAN_0_20_01","SOILTEMP_MEAN_0_50_01","SOILTEMP_MEAN_0_100_01")
    
    datlist = list(X1 = dati[,cols1],
                   X2 = data.frame(tair0150 = dati$AIRTEMP_MEAN_150_0_01))
    
    flaglist = list(X1 = flagi[,cols1],
                    X2 = data.frame(tair0150 = flagi$AIRTEMP_MEAN_150_0_01))
    
    collist = list(C1 = heightcols[1:4],
                   C2 = 'blue')
    
    ylabs = list(X1 = 'Soil Temperature (deg C)',X2 = 'Air Temperature (deg C)')
    
    flagplots(datlist = datlist,flaglist = flaglist,start = NULL,stop = NULL,plotcols = collist,
              xvar = tsi,ylabs = ylabs,
              plotname = paste0(writedir,'TSOIL/TSOIL_',xbounds[i],'.jpeg')) 
  }
  #............................................#
  
  #SOIL WATER CONTENT, 1.5M LEAF WETNESS, PRECIP
  #............................................#
  {
    cols1 = c("SOILWC_MEAN_0_10_01","SOILWC_MEAN_0_20_01","SOILWC_MEAN_0_50_01","SOILWC_MEAN_0_100_01")
    
    datlist = list(X1 = dati[,cols1],
                   X2 = data.frame(lw0150 = dati$LW_MEAN_150_0_01))
    
    flaglist = list(X1 = flagi[,cols1],
                    X2 = data.frame(lw0150 = flagi$LW_MEAN_150_0_01))
    
    collist = list(C1 = heightcols[1:4],
                   C2 = 'darkblue')
    
    ylabs = list(X1 = 'Soil Water Content (%)',X2 = 'Leaf wetness (mV)',X3 = 'Precipitation (mm)')
    
    flagplots(datlist = datlist,flaglist = flaglist,start = NULL,stop = NULL,plotcols = collist,
              xvar = tsi,ylabs = ylabs,
              plotname = paste0(writedir,'WCSOIL/WCSOIL_',xbounds[i],'.jpeg')) 
  }
  #............................................#
  
  #FOUR COMPONENT NET RADIATION
  #............................................#
  # {
  #   cols1 = c('p.swin','p.swout')
  #   cols2 = c('p.lwin','p.lwout')
  #   
  #   datlist = list(X1 = dati[,cols1],
  #                  X2 = dati[,cols2],
  #                  X3 = data.frame(p.netrad = dati$p.netrad))
  #   
  #   flaglist = list(X1 = flagi[,cols1],
  #                   X2 = flagi[,cols2],
  #                   X3 = data.frame(p.netrad = flagi$p.netrad))
  #   
  #   collist = list(C1 = heightcols[1:2],
  #                  C2 = heightcols[3:4],
  #                  C3 = heightcols[5])
  #   
  #   ylabs = list(X1 = 'Radiation (W/m2)',X2 = 'Radiation (W/m2)',X3 = 'Radiation (W/m2)')
  #   
  #   flagplots(datlist = datlist,flaglist = flaglist,start = NULL,stop = NULL,plotcols = collist,
  #             xvar = tsi,ylabs = ylabs,
  #             plotname = paste0(writdir,'RADIATION/RADIATION_',xbounds[i],'.jpeg')) 
  # }
  #............................................#
  
  
  #ATMOSPHERIC PRESSURE
  #............................................#
  # {
  #   
  #   datlist = list(X1 = data.frame(p.atmpress = dati$p.atmpress))
  #   
  #   flaglist = list(X1 = data.frame(p.atmpress = flagi$p.atmpress))
  #   
  #   collist = list(C1 = 'darkblue')
  #   
  #   ylabs = list(X1 = 'Atmospheric pressure (mbar)')
  #   
  #   flagplots(datlist = datlist,flaglist = flaglist,start = NULL,stop = NULL,plotcols = collist,
  #             xvar = tsi,ylabs = ylabs,
  #             plotname = paste0(writdir,'ATMPRESS/ATMPRESS_',xbounds[i],'.jpeg')) 
  # }
  #............................................#
  print(xbounds[i])
}
