
#TIMEPULL: cuts a dataset down to just the dates you are looking for 
#----------------------------------------------------------#
timepull = function(start,stop,x,ts = 'timestamp'){
  
  start = as.character(start)
  stop = as.character(stop)
  
  if(length(ts) == 1){
    tsID = which(colnames(x) == ts)
    ID1 = which(substr(x[,tsID],1,10) == start)[1]
    ID2 = tail(which(substr(x[,tsID],1,10) == stop),1)
  }
  
  if(length(ts) > 1){
    ID1 = which(substr(ts,1,nchar(start)) == start)[1]
    ID2 = tail(which(substr(ts,1,nchar(stop)) == stop),1)
  }

  if(is.null(dim(x)) == F){y = x[ID1:ID2,]}
  if(is.null(dim(x)) == T){y = x[ID1:ID2]}
  return(y)
}
#----------------------------------------------------------#

#HEIGHTCOLS: Not a function. Just color codes for discovery tree heights
#----------------------------------------------------------#
heightcols = colors()[c(566,430,261,258,555,505)]
names(heightcols) = c('0150','1000','2000','3000','4000','5600')
#Colors for 1.5, 10, 20, 30, 40 and 56m sensors on DT
#Colors are blue, light blue, black, green, red and orange
#Mimmicks provisional data plots on HJA website
#----------------------------------------------------------#


#LINEPLOT: Plotting function for anything that is a simple lineplot
#----------------------------------------------------------#
lineplot = function(dat = discovery,
                  start = NULL,
                  stop = NULL,
                  #nplot = NULL,
                  plotcols = heightcols,
                  xvar = 'timestamp',
                  yvars,
                  ylab = 'Leaf wetness (mV)'
                  ){
  
  #pull out timestamp (or whatever xvar we want)
  if(length(xvar) == 1){ts = dat[,which(colnames(dat) == xvar)]}
  if(length(xvar) > 1){ts = xvar}
  
  #Cut plotting data down if desired (start, stop, or both are not null)
  if(!is.null(start) & is.null(stop)){stop = substr(tail(ts,1),1,10); dat = timepull(dat,start = start, stop = stop)}
  if(is.null(start) & !is.null(stop)){start = substr(head(ts,1),1,10);dat = timepull(dat,start = start, stop = stop)}
  if(!is.null(start) & !is.null(stop)){dat = timepull(dat,start = start, stop = stop)}
  if(is.null(start) & is.null(stop)){start = substr(ts[1],1,10);stop = substr(tail(ts,1),1,10)}
  
  #Redo ts
  #if(length(ts) == 1){ts = dat[,which(colnames(dat) == xvar)]}
  
  #Pull out the barplot data if needed
  #if(!is.null(barvar)){bdat = dat[,which(colnames(dat) == barvar)]}
  
  #Pull out the data to plot
  if(ncol(dat) > 1){dat = dat[,match(yvars,colnames(dat))]}
  
  #Y axis range
  ylims = range(dat,na.rm=T)
  
  #Check if there is no data in this plot, insert dummy plot if not
  if(all(is.finite(ylims)) == T){bogus = F}
  if(all(is.finite(ylims)) == F){bogus = T;ylims = c(0,10)}
  if(diff(ylims) == 0){bogus = F;ylims = c(0,10)}
  
  #Leaf wetness plots
  #-----------------------------------------------------#
  #Set up the initial plot
  #if(par(mar = c(0,4,4,0)+.1)
  plot(x = ts,
       y = dat[,1],
       ylim = ylims,
       xlim = range(ts),
       ylab = ylab,
       xlab = '',
       main = paste0(start,' thru ',stop),
       las = 1,
       tck = .03,
       type = 'n',
       xaxs = 'i'
  )
       #xaxt = 'n')
  #axis.Date(1,at = seq(min(ts),max(ts),by = '2 day'))
  
  axis(side = 4, labels = F,tck = .03)
  
  abline(v = ts[which(substr(ts,12,16) == '00:00')],col = 'gray',lwd = .5)
  abline(v = ts[which(substr(ts,12,16) == '12:00')],col = 'gray',lwd = .5,lty = 2)
  #-----------------------------------------------------#
  
  #Loop through the data columns if ylims are valid
  if(bogus == F){for(i in 1:length(dat)){lines(x = ts, y = dat[,i],col = plotcols[i],lwd = 2)}}
  if(bogus == T){text(x = ts[round(length(ts)/2,0)], y = 5,labels = 'All data NA')}
  
  #Add the legend
  #legend(x = ts[1], y = ylims[1] - ((ylims[2] - ylims[1])*.25), xpd = NA, ncol = ncol(dat),legend = yvars, col = plotcols,lwd = 3)
  legend(x = 'topleft', ncol = 1,legend = yvars, fill = plotcols,bg = 'white')
  
  }
#----------------------------------------------------------#


#FLAGPLOTS: Plotting function for anything that is a simple lineplot.
#allows you to add any number of subplots
#adds 
#----------------------------------------------------------#
flagplots = function(datlist = datlist,
                     flaglist = flaglist,
                    start = NULL,
                    stop = NULL,
                    plotcols = heightcols,
                    xvar = 'timestamp',
                    ylabs,
                    plotname
){
  
#How many plots?
nplot = length(datlist)
  
jpeg(filename = plotname,width = 16, height = 9, units = 'in',res = 200)
#x11(width = 16, height = 9)
par(mfrow = c(nplot,1))
  
for(j in 1:nplot){
  
  datj = datlist[[j]]
  plotcolsj = collist[[j]]
  
  #Make the lineplot
  lineplot(dat = datj,
          plotcols = plotcolsj,
          xvar = tsi,
          yvars = colnames(datlist[[j]]),
          ylab = ylabs[[j]])
  
  #Add flags, if they exist
  #......................................................................#
  flagj = flaglist[[j]]
  plotflags = which(flagj == 'I' | flagj == 'Q' | flagj == 'V',arr.ind=T)
  if(length(plotflags) > 1){
    
    for(k in 1:nrow(plotflags)){
      
      flagval = flagj[plotflags[k,1],plotflags[k,2]]
      flagx = xvar[plotflags[k,1]]
      flagy = datj[plotflags[k,1],plotflags[k,2]]
      flagcol = plotcolsj[plotflags[k,2]]
      
      #Impossible: X
      if(flagval == 'I'){points(x = flagx,y = flagy,col = flagcol, pch = 4,cex=2,lwd=4)}
      
      #Questionable: Open circle
      if(flagval == 'Q'){points(x = flagx,y = flagy,col = flagcol, pch = 1,cex=2,lwd=4)}
      
      #Value changed: inverted triangle
      if(flagval == 'V'){points(x = flagx,y = flagy,col = flagcol, pch = 6,cex=2,lwd=4)}
    }
    #add the legend
    legend(x = 'topright',pch = c(4,1,6),col = 'black',legend = c('I','Q','V'),title = 'Flags',bg='white')
  }
  #......................................................................#
  
}     
dev.off()  
}
#----------------------------------------------------------#


#SCREENBOI: Function that takes any values for given variables
#in a given time range and changes them to NA. Can be flag
#or range based.
#----------------------------------------------------------#
screenboi = function(derivs = NULL, badflag = NULL, goodrange = NULL,...){
    
  #If filtering on the basis of flags
  if(!is.null(badflag)){
    for(i in 1:length(vars)){
      for(j in 1:length(badflag)){
        naID = which(flag[,vars[i]] == badflag[j])
        naID = naID[which(ts[naID] >= from & ts[naID] <= to)]
        if(length(naID) > 0){
          dat[naID,vars[i]] = NA
          flag[naID,vars[i]] = 'R'
          if(!is.null(derivs)){
            for(k in 1:length(derivs)){
              dat[naID,derivs[k]] = NA
              flag[naID,derivs[k]] = 'R'
            }
          }
        }  
      }
    }
  }
  
  #If filtering on the basis of goodrange
  if(!is.null(goodrange)){
    for(i in 1:length(vars)){
      for(j in 1:length(badflag)){
        naID = which(dat[,vars[i]] < goodrange[1] | dat[,vars[i]] > goodrange[2])
        naID = naID[which(ts[naID] >= from & ts[naID] <= to)]
        if(length(naID) > 0){
          dat[naID,vars[i]] = NA
          flag[naID,vars[i]] = 'R'
          if(!is.null(derivs)){
            for(k in 1:length(derivs)){
              dat[naID,derivs[k]] = NA
              flag[naID,derivs[k]] = 'R'
            }
          }
        }  
      }
    }
  }
  dat <<- dat
  flag <<- flag
}
#----------------------------------------------------------#


#REMOVE.DEPENDENT: Function that removes entries from secondary (calculated) variables, based on the fundamental 
#Measurements they are calculated from. Any "R" entries in fundamental vars flag data frame will be removed in secondary
#variables as well. 
#----------------------------------------------------------#
remove.dependent = function(){
  
  deplist = list(AIRTEMP_MEAN_150_0_01 = c("DEWPT_MEAN_150_0_01","SATVAPAIR_MEAN_150_0_01" ,"SATVAPDEW_MEAN_150_0_01","VPD_MEAN_150_0_01"),
                 AIRTEMP_MEAN_5600_0_01 = c("DEWPT_MEAN_5600_0_01","SATVAPAIR_MEAN_5600_0_01" ,"SATVAPDEW_MEAN_5600_0_01","VPD_MEAN_5600_0_01"))
  
  for(i in 1:length(deplist)){
    depi = deplist[[i]]
    rmID = which(flag[,names(deplist)[i]] == 'R')
    if(length(rmID) > 0){
      for(j in 1:length(depi)){
        flag[rmID,depi[j]] = 'R'
        dat[rmID,depi[j]] = NA
      }
    }
  }
  
  dat <<- dat  
  flag <<- flag  
}
#----------------------------------------------------------#

#FLAGPRINT: 
#----------------------------------------------------------#
flagprint = function(dat,flag,ts,flagp,l){
  
  #Function to help us later with building the report
  checkl = function(l){if(l < -35){frame();l = 8};return(l)}
  
  if(flagp == 'R'){
    mtext(bquote(underline(.('Removed Values'))),cex = 1.5, font = 2, outer = F,line = l,adj = 0)
    messagetxt = 'removed'
  }
  l = l-2
  l = checkl(l)
  
  for(i in 1:ncol(dat)){
    
    #Flag ID
    fID = which(flag[,i] == flagp)
    if(length(fID) == 0){next}
    
    #Print the name of the variable
    mtext(bquote(.(colnames(dat)[i])),cex = 1.3, font = 2, outer = F,line = l,adj = 0)
    l = l-1
    l = checkl(l)
    
    #Get the days the flags are on, take differences
    tsi = as.POSIXct(substr(ts[fID],1,10))
    tsdiff = diff(tsi)
    
    #Identify the time differences that are greater than 1 day
    daygap = which(tsdiff > (60*60*24))
    
    #If there are no daygaps greater than 1 day:
    if(length(daygap) == 0){
      mtext(paste0(length(tsi),' records ',messagetxt,' between ',tsi[1],' and ',tail(tsi,1)),outer = F,line = l, adj = 0)
      l = l-2
      l = checkl(l)
    }
    
    #If there are 1 or more daygaps in the record
    if(length(daygap) >= 1){
      
      daygap = c(1,daygap,length(tsi))
      
      for(j in 2:length(daygap)){
        
        #How many values between the previous large gap and this one?
        #if(j == 1){flagnum = daygap[1];tsi1 = tsi[1];tsi2 = tsi[daygap[j]]}
        
        #if(j > 1 & j < length(daygap)){
          flagnum = daygap[j]-daygap[j-1]
           tsi1 = tsi[daygap[j-1]+1]
          tsi2 = tsi[daygap[j]]
         # }
        
        # if(j == length(daygap)){
        #   flagnum = length(tsi)-daygap[j]
        #   tsi1 = tsi[daygap[j]]
        #   tsi2 = tail(tsi,1)
        #   }
      
      mtext(paste0(flagnum,' records ',messagetxt,' between ',tsi1,' and ',tsi2),outer = F,line = l, adj = 0)
      l = l-1
      l = checkl(l)
      }
      l = l-1
      l = checkl(l)
    }
  }
  
  return(l) 
}  
#----------------------------------------------------------#





  