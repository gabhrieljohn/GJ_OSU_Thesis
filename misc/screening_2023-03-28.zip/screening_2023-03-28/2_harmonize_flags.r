#Set timezone 
Sys.setenv(TZ = 'PST')

#Read the data
load('~/data/HJA/discovery_tree/screening_2023-03-28/dt_and_flag_screening_v0.Rdat')

#DEAL WITH FLAGS
#-------------------------------------------------------#
#Figure out what the unique flag values are in the data
uflag = unique(unlist(apply(flag,2,unique)))

#I = impossible
#Q = questionable
#M = missing
#E = ???
#V = Value change
#T = primet soil water content
#C = Non asp air temp, primet RH, primet vpd, rpimet vap
#B = Part of snow flags

#Any flag that is M keep M
#Any flag that is I keep I
#Any flag that is V keep V
#Any flag that is Q, T, C, E or B, change to Q
#Any flag that is NA or "", change to N (for "Normal")

#makeI = which(flag == 'IQ' | flag == 'IVIQ' | flag == 'VIQ' | flag == 'IVQ' | flag == 'VI' | flag == 'MI' | flag == 'QI', arr.ind = T)
makeI = which(flag == 'IQ' | flag == 'MI' , arr.ind = T)
flag[makeI] = 'I'

#makeM = which(flag == 'MM' | flag == 'MMM' | flag == 'MT' | flag == 'EM',arr.ind=T)
makeM = which(flag == 'MM' | flag == 'MQ',arr.ind=T)
flag[makeM] = 'M'

#makeQ = which(flag == 'VQ' | flag == 'QV' | flag == 'T' | flag == 'C' | flag == 'E' | flag == 'B' | flag == 'NB',arr.ind=T)
#flag[makeQ] = 'Q'

makeN = which(is.na(flag) | flag == '',arr.ind=T)
flag[makeN] = 'N'

#change the name of the columns in flag
colnames(flag) = substr(colnames(flag),6,nchar(colnames(flag)))

#Save that out!
save(list = c('ts','dat','flag'),file = '~/data/HJA/discovery_tree/screening_2023-03-28/dt_and_flag_screening_v0.1.Rdat')
#-------------------------------------------------------#
