makewet = function(dat,timestamp,rain,leafwet,Tair){
  
  #INITIAL SETUP
  ###########################################################################
  
  #Span - in number of timestamps - since last rain
  span = 24
  
  #Lets use a leaf wetness thresh of 275 shall we?
  lwthresh = 275
  
  #What should we use for a frost thresh? Fill in 300 for now
  frost.thresh =  300
  
  #Setting up the initial vectors
  rf = dat[,rain]
  lw = dat[,leafwet]
  ts = dat[,timestamp]
  wet = rep(NA,length(rf))
  
  #ts.length - what timestamp interval are we working with here? In units of minutes
  ts.length = as.numeric(difftime(ts[2],ts[1],units = 'mins'))
  
  #Make a binary vector of freezing/not freezing temps
  Tairbin = rep(NA,length(Tair))
  Tairbin[which(Tair > 0)] = 1
  Tairbin[which(Tair <= 0)] = 0
  
  #Freezing temperature RLE and boundaries of runs
  freeze.rle = rle(Tairbin)
  freeze.vals = freeze.rle$values
  freeze.boundaries = cumsum(freeze.rle$lengths)
  
  #For now, fill in NAs in rf with zeros. there aren't many: it is easiest.
  rf[which(is.na(rf))] = 0
  ###########################################################################
  
  #START THE LOOP
  for(i in span:length(ts)){
    
    #MISSING DATA
    #.......................................................................#
    if(is.na(lw[i])){next}
    #.......................................................................#
    
    #DRY SENSOR
    #.......................................................................#
    if(lw[i] < lwthresh){
      
      #If the temperature is not freezing, just mark it dry
      if(Tairbin[i] == 1){wet[i] = 0;next}
      
    }
    #.......................................................................#
    
    
    #FROST
    #.......................................................................#
    if(Tairbin[i] == 0 & lw[i] > frost.thresh){
      
      #Determine when the frost started
      frost.start = freeze.boundaries[tail(which(freeze.boundaries < i),1)]
      
      #Determine when the frost ends
      frost.end = freeze.boundaries[head(which(freeze.boundaries > i),1)]
      
      #Before the freeze starts, was the sensor wet? 
      prefrost.wet = mean(lw[(frost.start-((60+ts.length)/ts.length)):(frost.start-1)],na.rm=T)
      
      #As we are above frost thresh, and Tair > 0C, mark this wet value "frost" regardless
      wet[i] = 4
      
      #Record the pre-frost wetness state, for later steps of the code
      if(prefrost.wet < lwthresh){prefrost.state = 1}
      if(prefrost.wet > lwthresh & wet[(frost.start-1)] == 2){prefrost.state = 2}
      if(prefrost.wet > lwthresh & wet[(frost.start-1)] == 3){prefrost.state = 3}
      
      #Skip to next iteration
      next
      }
    #.......................................................................#
    
    #WET SENSOR
    #########################################################################
    #If the rainfall value is NA, just use the wet value from the last iteration (lazy for now, but only 12 NAs in this whole record)
    if(is.na(rf[i])){wet[i] = wet[i-1];next}
    
    #If the sensor is wet
    if(lw[i] >= lwthresh){
      
      #was there rain in the last SPAN?
      if(any(rf[(i+1-span):i] > 0)){wet[i] = 1;next}
      
      #if there was no rain: was the previous wet value (2)? Make this one 2 as well
      if(!is.na(wet[i-1])){if(wet[i-1] == 2){wet[i] = 2;next}}
      
      #If there was no rain, and pre-frost wetness state was not 1, was there frost in the previous 30 minutes? If so, use the pre-frost wetness state.
      if(any(wet[((i-(30/ts.length)):(i-1)] == 4) & prefrost.wet != 1){wet[i] = prefrost.wet;next}
      
         
      #We are farther than SPAN from the last rain but we have not detected dewfall yet. So: slope based wetness attribution
      #.......................................................................#
      #When was the last rain?
      if(i <= 3000){ID = 1:i}
      if(i > 3000){ID = (i-3000):i}
      
      lastrain = which(rev(rf[ID]) > 0)[1]
      if(is.na(lastrain) == F){rID = (i-lastrain+1):i}
      if(is.na(lastrain)){rID = ID}

      #Has the general trend been drying out? and is the current trend drying out?
      naID = which(!is.na(lw[rID]))
      y = lw[rID]
      y = y[naID]
      x = 1:length(y)
      
      #If all of that lw data is bogus, but this one is good, mark it ambiguous
      if(length(y) <= 1){wet[i] = 3;next}
      
      #Has it been dry at all since that last rain? If it has, call this dew (2)
      #if(any(lw[rID] < lwthresh)){wet[i] = 2;next}
      if(any(y < lwthresh)){wet[i] = 2;next}
      
      #Has it never been dry since the last rain?
      if(all(y >= lwthresh)){
        
        gentrend = lm(y~x)$coefficients[2]
        loctrend = lm(lw[(i-2):(i+2)]~c(1:5))$coefficients[2]

        #LOOK INTO WHAT THESE THRESHOLDS NEED TO BE
        if(gentrend < 0 & loctrend < 0){wet[i] = 1;next}else{
          if(loctrend >= 2){wet[i] = 2;next}else{wet[i] = 3}
        }
        
      }
    }
    #.......................................................................#
    #########################################################################
  }
  return(wet)
}