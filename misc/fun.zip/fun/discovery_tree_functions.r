

timepull = function(start,stop,x){
  ID1 = which(substr(x$timestamp,1,10) == start)[1]
  ID2 = tail(which(substr(x$timestamp,1,10) == stop),1)
  
  y = x[ID1:ID2,]
  return(y)
}
