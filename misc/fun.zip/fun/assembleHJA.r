assembleHJA = function(newlist = NULL,vnames,vname_type = 'original', drange = NULL){
#Assemble - A function written to bring together all the data.


#Establish earliest and latest timestamps in record
#-------------------------------------------------#
if(is.null(drange) == T){
  #This is the original line....but it makes no sense. where do the i and j come from? Worrying. i and j should be set to 1. 
  #drange = range(newlist[[i]][[j]]$Date)
  
  #Substitute line for above, where i and j are set to 1
  drange = range(newlist[[1]][[1]]$Date)
  
  for(i in 1:length(newlist)){
    for(j in 1:length(newlist[[i]])){
      drange = c(drange,range(newlist[[i]][[j]]$Date))
    }
  }
  drange = range(drange)
}
#-------------------------------------------------#

#Make a timestamp list to fill in, using time difference between first two timestamps in first data table as our guide

ts = seq(drange[1],drange[2],by = diff(newlist[[1]][[1]]$Date[1:2]))
  
#Make the data frame with all the columns we want
if(vname_type == 'all'){
  unames = unique(vnames$all)
  dat = data.frame(timestamp = ts,matrix(data = as.numeric(NA),nrow = length(ts),ncol = length(unames)))
  colnames(dat) = c('timestamp',unames)
}

if(vname_type == 'original'){
  unames = unique(vnames$original)
  dat = data.frame(timestamp = ts,matrix(data = as.numeric(NA),nrow = length(ts),ncol = length(unames)))
  cnames = c('timestamp',unames)
  colnames(dat) = cnames
}

#Loop through all data frames, fill in data we want in the columns we want
#------------------------------------------------------------------------#
for(i in 1:length(newlist)){
  for(j in 1:length(newlist[[i]])){
    
    idat = newlist[[i]][[j]]
    
    #Get the match on the timestamps
    matchID = match(idat$Date,ts)
    
    #What columns in the raw data should go in the final data?
    if(vname_type == 'all'){
      rawcolID = na.omit(match(vnames[,'original'],colnames(idat)))
      rawcols = colnames(idat)[rawcolID]
    
      #Where are these located in the final data header?
      finalcolID = match(vnames[match(rawcols,vnames$original),'all'],colnames(dat))
    }
    
    if(vname_type == 'original'){      
      rawcolID = na.omit(match(colnames(dat),colnames(idat)))
      rawcols = colnames(idat)[rawcolID]
      finalcolID = match(rawcols,colnames(dat))
    }
    
    #Fill em in
    for(k in 1:length(rawcolID)){dat[matchID,finalcolID[k]] = idat[,rawcolID[k]]}
  }
}
#------------------------------------------------------------------------#

return(dat)
}
