plotpoly = function(dates,heights = c(0,10,20,30),cnames,tallness = 35,dat = dat,scalevals = c(260,800), main = dates){
  
  #Regrowth ("young" ) tree has sensors at 5, 15 and 25. So make the breaks at 0, 10, 20 and 30. Make the tree 35m tall. 
  #heights = c(0,10,20,30)
  #tallness = 35
  
  cts = cnames[1]
  cnames = cnames[-(1)]
  
  #Function to turn the above height vectors into vertices for polygon plotting
  polyhts = function(htvec){htpoly = cbind(htvec[1:length(htvec)-1],htvec[2:length(htvec)],htvec[2:length(htvec)],htvec[1:length(htvec)-1])}
  
  #Polygon heights
  htpoly = polyhts(heights)

  #Pull out our period of interest
  tspull = head(which(substr(dat[,cts],1,10) == dates[1]),1):tail(which(substr(dat[,cts],1,10) == dates[2]),1)
  Pdat = dat[tspull,]
  Pts = Pdat[,cts]
  Pdat = Pdat[,match(cnames,colnames(Pdat))]
  
  #Scale leaf wetness to predefined max/min
  #mymin = 260
  #mymax = 800
  Pdat = round(100*(Pdat-scalevals[1])/(scalevals[2]-scalevals[1]),0)
  
  #Color ramp adjusted to sensor response range
  #max-min = 800-260
  #We want the dry range to be 260-315
  #315-600 = various degrees of wetness
  #600 - 800 = soaking wet
  #So first 10% should be red, 
  #Next 53% Various shade of Blue
  #Last 37% should be deep blue. 

  plotcolors = list(color = c(
    colorRampPalette(colors()[c(555,411)])(10),
    colorRampPalette(colors()[c(411,121)])(10),
    colorRampPalette(colors()[c(121,132)])(43),
    rep(colors()[132],37)
  ))
  
  #Get rid of 0s
  Pdat[which(Pdat <= 0,arr.ind=T)] = 1
  
  #Get rid of > 100
  Pdat[which(Pdat > 100,arr.ind=T)] = 100
  
  #Dummy plot
  test= plot(x = Pts, 
             y = rep(1,length(Pts)),
             ylim = c(0,tallness),
             yaxs = 'i',
             xaxs = 'i',
             type = 'n',
             xlab = '',
             ylab = 'Height (m)',
             #yaxp = c(0,80,80/5),
             xaxt = 'n',
             las = 1,
             main = main,
             cex.main = 2,
             cex.lab = 1.5,
             cex.axis = 1.5
  )
  
  #Draw the polygon for the tree height
  polygon(x = c(rep(Pts[1],2),rep(tail(Pts,1),2)), y = c(0,tallness,tallness,0),col ='lightgray')
  
  #Now loop the days and heights, plot the data polygons!
  for(i in 1:length(Pts)-1){
    polydate = Pts[i:(i+1)]
    polyx = c(rep(polydate[1],2),rep(polydate[2],2))
    for(j in 1:nrow(htpoly)){polygon(x = polyx, y = htpoly[j,],col = plotcolors$color[Pdat[i,j]],border=NA)}
  }
  
  #Add lines, draw x axis
  midnite = Pts[which(substr(Pts,12,19) == '00:00:00')]
  noon =    Pts[which(substr(Pts,12,19) == '12:00:00')]
  #axis.POSIXct(1,at=midnite,labels=format(midnite,"%b-%d"),las=1,cex.axis = 1.5)
  
  for(j in 1:length(midnite)){
    lines(x = rep(noon[j],2),y = c(-3,tallness),col='black',lty=2,lwd=.5)
    if(j > 1){lines(x = rep(midnite[j],2),y = c(-3,tallness),col='black',lty=1,lwd=.5)}
  }
  
  #Add the legend
  xpos = quantile(noon, probs = seq(0,1,0.1))
  color.legend(xl = xpos[9],xr = xpos[11],yb = 72, yt = 75,legend = c('dry','wet'),rect.col = plotcolors$color,cex = 2)
  
}
