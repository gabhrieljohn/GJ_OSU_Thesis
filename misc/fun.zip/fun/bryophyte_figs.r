source('~/rscripts/discovery_tree/fun/plotpoly.r')
library(plotrix)
library(ggplot2)


#A little function to impose extra wetness, given the drytime of the different species
wetter = function(lwdat,drytime){
  
  for(i in 1:ncol(lwdat)){
    
    runs = rle(lwdat[,i])
    rlength = runs$length
    rvals = runs$values
    
    zeros = which(rvals == 0)
    if(zeros[1] == 1){zeros = zeros[-(1)]}
    
    for(j in 1:length(zeros)){
      new1s = sum(rlength[1:zeros[j]])
      lwdat[(new1s):min(new1s+drytime,nrow(lwdat)),i] = 1
    }
  }
  return(lwdat)
}

#Read in the data and do all dakine
load('~/data/discovery_tree/met_all.Rdat')
dates = as.POSIXct(c('2017-10-11','2017-11-11'))
tspull = head(which(substr(discovery$timestamp,1,10) == dates[1]),1):tail(which(substr(discovery$timestamp,1,10) == dates[2]),1)
dat = discovery[tspull,]

dat = dat[which(dat$p.swin > 10),]

ts = dat$timestamp
lw = dat[,10:15]

#Whats dry and whats wet?
#From 260 - 350 = dry
#From 351 - 800 = wet

#Code it to just be wet/dry 
lw01 = matrix(0,ncol = ncol(lw),nrow = nrow(lw))
lw01[which(lw > 350,arr.ind = T)] = 1
colnames(lw01) = c('lw0150','lw1000','lw2000','lw3000','lw4000','lw5000')

#OK, what do we use for the critical switch in water to dry weight ratio from net positive to net negative?
#What the fuck, say 1.5

#OK, what are the critical drying out thresholds for the different species?
#Isothesium - 3 hours
#Porella - 18 hours
#Dicranum - 30 hours
#Neckera - 38 hours

#Make dakine
isothesium = wetter(lw01,3*12)
porella = wetter(lw01,18*12)
dicranum = wetter(lw01,30*12)
neckera = wetter(lw01,38*12)

#OK, now what are the zones these shits grow in?
#Isothecium - 1.5 - 45m
#Porella - 15 - 35m
#Dicranum - 15 - 35m
#Neckera - 15-35m

#Isothecium
#-------------------------------------------------------------------------#
heights = c(0,5,15,25,35,45,55)
tallness = 70
main = 'Isothecium'
brange = c(1.5,45)

par(mar = c(4,4.2,4.1,2.1))
jpeg(filename = paste('~/data/discovery_tree/figs/isothecium2_',dates[1],'.jpeg',sep=''),width = 10, height = 4, units = 'in',res = 300)

plotpoly_bryo(heights = heights, tallness = tallness, dat = isothesium, Pts = ts, main = main,brange=brange)
dev.off()
#-------------------------------------------------------------------------#

#Porella
#-------------------------------------------------------------------------#
heights = c(0,5,15,25,35,45,55)
tallness = 70
main = 'Porella'
brange = c(15,35)

par(mar = c(4,4.2,4.1,2.1))
jpeg(filename = paste('~/data/discovery_tree/figs/Porella_',dates[1],'.jpeg',sep=''),width = 10, height = 4, units = 'in',res = 300)

plotpoly_bryo(heights = heights, tallness = tallness, dat = porella, Pts = ts, main = main,brange=brange)
dev.off()
#-------------------------------------------------------------------------#

#Dicranum
#-------------------------------------------------------------------------#
heights = c(0,5,15,25,35,45,55)
tallness = 70
main = 'Dicranum'
brange = c(15,35)

par(mar = c(4,4.2,4.1,2.1))
jpeg(filename = paste('~/data/discovery_tree/figs/Dicranum_',dates[1],'.jpeg',sep=''),width = 10, height = 4, units = 'in',res = 300)

plotpoly_bryo(heights = heights, tallness = tallness, dat = dicranum, Pts = ts, main = main,brange=brange)
dev.off()
#-------------------------------------------------------------------------#



#Neckera
#-------------------------------------------------------------------------#
heights = c(0,5,15,25,35,45,55)
tallness = 70
main = 'Neckera'
brange = c(15,35)

par(mar = c(4,4.2,4.1,2.1))
jpeg(filename = paste('~/data/discovery_tree/figs/neckera_',dates[1],'.jpeg',sep=''),width = 10, height = 4, units = 'in',res = 300)

plotpoly_bryo(heights = heights, tallness = tallness, dat = neckera, Pts = ts, main = main,brange=brange)
dev.off()
#-------------------------------------------------------------------------#


