climreadHJA = function(loc, nice = 0, screened = 0,timezone = 'PST'){
#This function originally based on the sapread function.
#"Nice" option introduced on 2017-01-23.
  
#If Nice = 0, data is processed the old way (to maintain compatability with older scripts
#which used the old format).
  
#If Nice = 1, columns are formatted so that timestamp is posixCT, numbers are numeric, etc...
#Extra headers are discarded, main header is used on the data table. 
  
#If Nice = 1, column names and classes are tested at the same time. 
#For example, SWup_Avg is tested to see if it exists and if the class is character.
#If both are true, SWup_Avg class is fixed from character to numeric. 
  
#New tests can be added as needed (for example, if for some reason SWup_Avg gets read in
#as a factor, add a new if statement to test for SWup_Avg presence and if its class is factor).

#Screened = 0 by default. Can be set to 0 or 1. 
#Screened = 0 means headers are handled as they are in raw data (four header lines).
#Screened = 1 means headers are handled as they are in screened data (one header line).
#In screened data, NAs = -9999. For handling in R, they are converted to NA here. 
#------------------------------------------------------------------------------------------#

#Reading in the data
if(screened == 0){dat = read.table(loc, sep = ',', skip = 5, header = F, stringsAsFactors = F)}
if(screened == 1){dat = read.table(loc, sep = ',', skip = 1, header = F, stringsAsFactors = F)}

#NICE = 1  
if(nice == 1){
  
  #Adding headers
  if(screened == 0){header = as.character(as.matrix(read.table(loc, sep = ',', skip = 2, nrows = 1, header = F)))
  colnames(dat) = header}
  
  if(screened == 1){header = as.character(as.matrix(read.table(loc, sep = ',',nrows = 1, header = F)))
  colnames(dat) = header}
  
  #Retrieve class of all columns
  classes = rep(0,dim(dat)[2])
  for(i in 1:dim(dat)[2]){classes[i] = class(dat[,i])}
  names(classes) = header
  
  #TIMESTAMP
  #------------------------------------------------------------------#
  if(exists(classes['Date']) & classes['Date'] == 'character'){

    Sys.setenv(TZ=timezone)

    dat$Date = strptime(as.character(dat$Date),'%Y-%m-%d %H:%M:%S')
    dat$Date = as.POSIXct(dat$Date)
  }
  #------------------------------------------------------------------#

  #yyyy-mm-dd hh:mm
  #------------------------------------------------------------------#
  if(exists(classes['yyyy-mm-dd hh:mm:ss']) & classes['yyyy-mm-dd hh:mm:ss'] == 'character'){
    
    dat[,'yyyy-mm-dd hh:mm'] = as.POSIXct(as.character(dat[,'yyyy-mm-dd hh:mm']),format = '%Y-%m-%d %H:%M',tz = timezone)
  }
  #------------------------------------------------------------------#
  
  #For everything other than the timestamp, convert factors to numeric
  #------------------------------------------------------------------#
  facID = which(classes == 'factor' & header != 'Date' & header != 'yyyy-mm-dd hh:mm:ss')
  
  if(length(facID) > 0){
    for(i in 1:length(facID)){dat[,facID[i]] = as.numeric(as.character(dat[,facID[i]]))}
  }
  #------------------------------------------------------------------#
  
  #For everything other than the timestamp, convert integers to numeric
  #------------------------------------------------------------------#
  intID = which(classes == 'integer' & header != 'Date' & header != 'yyyy-mm-dd hh:mm:ss')
  
  if(length(intID) > 0){
    for(i in 1:length(intID)){dat[,intID[i]] = as.numeric(dat[,intID[i]])}
  }
  #------------------------------------------------------------------#

  #For everything other than the timestamp, convert characters to numeric
  #------------------------------------------------------------------#
  charID = which(classes == 'character' & header != 'Date' & header != 'yyyy-mm-dd hh:mm:ss')
  
  if(length(charID) > 0){
    for(i in 1:length(charID)){dat[,charID[i]] = as.numeric(dat[,charID[i]])}
  }
  #------------------------------------------------------------------#
  
  #Changing -9999 to NA in screened data
  if(screened == 1){dat[dat == -9999] = NA}
  
  #Redoing the class check and printing it with the read-in classes
  classes2 = rep(0,dim(dat)[2])
  for(i in 1:dim(dat)[2]){classes2[i] = class(dat[,i])[1]}
  names(classes2) = header
  
  printclass = rbind(classes,classes2)
  rownames(printclass) = c('Original','Fixed')
  
  #print(printclass)
  
  
#Returning the result  
return(dat)
}
  
  


#NICE = 0, THE OLD WAY OF READING THE CLIM DATA IN
if(nice == 0){
  
#Creating a timestamp record that is POSIX format
ptime = strptime(dat[,1],'%Y-%m-%d %H:%M:%S')

#Converting timestamp to character
dat$V1 = as.character(dat$V1)

#Headers
header1 = as.character(as.matrix(read.table(loc, sep = ',', nrows = 1, header = F)))
header2 = as.character(as.matrix(read.table(loc, sep = ',', skip = 1, nrows = 1, header = F)))
header3 = as.character(as.matrix(read.table(loc, sep = ',', skip = 2, nrows = 1, header = F)))
header4 = as.character(as.matrix(read.table(loc, sep = ',', skip = 3, nrows = 1, header = F)))
header4[is.na(header4)] = ""

#Packaging the data into a list 
x = list(dat,header1,header2,header3,header4,ptime)
names(x) = c('dat','header1','header2','header3','header4','time')

return(x)
}
}












