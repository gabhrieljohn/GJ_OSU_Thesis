rain_wetting = function(dat,ts,rainfall,span,leafwet,lwthresh = 350){
#This function uses rle() to identify when the canopy experienced a rainfall event.
#Then, it determines when it became wet and determines how long it stayed wet based on the leafwetness 
#rainfall = name of rainfall column
#leafwet = name of leaf wetness column (only does one at the moment)
#span = how many time periods can elapse with no rainfall before you start to consider the rain event over?
        #specified in hours


#The timestep in the current data, in hours
timestep = as.numeric(difftime(ts[2],ts[1],units = 'hours'))

#Convert the span in units of hours to units of # of timestamps
span = span/timestep

rf = dat[,rainfall]
lw = dat[,leafwet]

#Get rid of NaNs, they mess things up
rf[which(is.nan(rf))] = NA
lw[which(is.nan(lw))] = NA

#Make a binary vector for rainfall
rfbin = rf
rfbin[rfbin <= 0] = 0
rfbin[rfbin > 0] = 1

#Make a binary vector for leaf wetness
lwbin = lw
lwbin[lwbin <= lwthresh] = 0
lwbin[lwbin > lwthresh] = 1

#IDENTIFY RAINFALL EVENTS. FILL IN "RAINLESS" PERIODS BETWEEN 
#----------------------------------------------------------------------------------#
  
#OK, do the RLE for the precip
rf.rle = rle(rfbin)

#Find all 0 runs that are shorter than span, turn them to 1s, then redo the rf.rle:
if(span > 0){
zeros = which(rf.rle$values == 0)
zeros = zeros[which(rf.rle$lengths[zeros] <= span)]

#If the sequence begins with a run of 0s shorter than span, remove that from consideration 
if(zeros[1] == 1){zeros = zeros[-(1)]}

zstarts = sapply(zeros-1, function(x) sum(rf.rle$lengths[1:x]))
zends = sapply(zeros, function(x) sum(rf.rle$lengths[1:x]))

#zsize = rf.rle$lengths[zeros]
for(i in 1:length(zstarts)){rfbin[zstarts[i]:zends[i]] = 1}

#Redo the rf.rle
rf.rle = rle(rfbin)
}
#----------------------------------------------------------------------------------#


#RUN THROUGH EVENTS, BUILD STATLIST
#----------------------------------------------------------------------------------#
slist = list()
listnames = c()

events = which(rf.rle$values == 1)

for(i in 1:length(events)){
  
  event = events[i]
  
  #ID of start/end of event
  rID = (sum(rf.rle$lengths[1:(event-1)])+1):sum(rf.rle$lengths[1:event])
  
  #If the event is only 1 timestamp long, do not bother with it. This is a lazy out for now.
  if(length(rID) <= 1){next}
  
  #If canopy was already wet, skip this rain event. Checks 5 lwbin values before the rain event. If any 1's are found, skip.
  #| If no leaf wetness data exists for those same 5 values, skip. 
  antecedent.lw = lwbin[(rID[1]-5):(rID[1]-1)]
  antecedent.lw = na.omit(antecedent.lw)
  if(length(antecedent.lw) == 0){next}
  if(any(antecedent.lw == 1)){next}
  
  #ID from the end of the event to the beginning of next event
  rID2 = (sum(rf.rle$lengths[1:event])+1):(sum(rf.rle$lengths[1:(event+1)])-1)
  
  #Does the canopy dry out in this period? If so, shorten rID2 to when that happens
  if(any(na.omit(lwbin[rID2]) == 0)){rID2 = rID2[1:which(lwbin[rID2] == 0)[1]]}
  
  #Does the LW trend upwards more than +75? If so, shorten rID2 to when that happens
  #Note 2019-07-01: This may be a little too much complexity to include. 
  #Basically it is a test to make sure non-rain wetting doesn't add to our wetness totals
  #I'm sure it can happen but for now lets comment it out for simplicity in explaning what we are doing
  #if(any(cumsum(diff(lw[rID2])) >= 75)){rID2 = rID2[1:which(cumsum(diff(lw[rID2])) >= 75)[1]]}
  
  #OK, now we can grab out the data
  dati = dat[rID[1]:tail(rID2,1),]
  
  #What stats to do?
  #1 - Total rainfall
  #2 - Duration of rain event
  #3 - Rainfall intensity
  #4 - Max wetness
  #5 - Wetting rate (start of dat to max wetness)
  #6 - Drying duration
  #7 - Drying rate (max wetness to end of record)
  #8 - VPD during drying time 
  #9 - Time between last precip and peak wetness (let it go negative, would be the drizzly rains methinks)
  #10 - Some kind of cumulative wetting? In that case, average VPD during entire interval?
  
  #1) Total rainfall
  rf.tot = sum(dati$p.precip,na.rm=T)
  
  #2) Duration of rain event, in hours
  tid = which(dati$p.precip > 0)
  rf.l = diff(range(tid))*timestep
  if(rf.l == 0){rf.l = timestep}
  
  #3) Rainfall intensity: mm/hour
  rf.intense = rf.tot/rf.l

  #4) Maximum leaf wetness
  lw.max = max(dati[,leafwet],na.rm=T)
  
  #5)Sum of leaf wetting. Use the wetness value just prior to the rainfall event as a baseline. 
  #lw.tot = sum(dati[,leafwet])-(nrow(dati)*lwthresh)
  lw.tot = sum(dati[,leafwet])-nrow(dati)*mean(dat[((rID[1])-5):(rID[1]-1),leafwet],na.rm=T)
  
  #6) Wetting rate - from start of rain to max
  tid2 = 1:(which(dati[,leafwet] == lw.max)[1])
  lw.rate = (lw.max - dati[1,leafwet])/((length(tid)-1)*timestep)
  if(length(tid2) == 1){lw.rate = NA}
  
  #7) Drying duration - how long was it drying out (maybe not the most important metric, just something to check if we get weird rates)
  tid3 = tail(tid2,1):nrow(dati)
  dry.l = (length(tid3)-1)*timestep
  
  #8) Drying rate
  dry.rate = (lw.max - dati[nrow(dati),leafwet])/(dry.l)
  
  #9) Mean VPD during the drying time
  dry.vpd = mean(dati$vpd5600[tid3],na.rm=T)
  
  #10) Timestamp of first rain
  rf.ts = dati$ts[1]
  
  #make a data frame of stats
  stats = data.frame(rf.tot,rf.l,rf.intense,lw.max,lw.tot,lw.rate,dry.l,dry.rate,dry.vpd,rf.ts)
  
  #Put em together
  minilist = list(dati,stats)
  names(minilist) = c('dat','stats')
  
  #make a list element, named for the timestamp of the first raindrep
  slist[[length(slist)+1]] = minilist
  listnames[length(listnames)+1] = as.character(dati$timestamp[1])
}

return(slist)
}
