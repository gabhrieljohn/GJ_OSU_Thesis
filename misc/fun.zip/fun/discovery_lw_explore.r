#Some functions, libraries, and the main data
source('~/rscripts/discovery_tree/fun/plotpoly.r')
library(plotrix)
library(ggplot2)
load('~/data/discovery_tree/met_all.Rdat')
load('~/data/discovery_tree/regrowth_lw.Rdat')

#The poster is 48" wide, 36" tall

#Some user defined functions
#---------------------------------------------------------------------------#
#Simple barplot function
simplebar = function(dates,dat,cnames){
  
  #Separate out the 
  cts = cnames[1]
  cnames = cnames[-(1)]
  
  tspull = head(which(substr(dat[,cts],1,10) == dates[1]),1):tail(which(substr(dat[,cts],1,10) == dates[2]),1)
  
  bardat = dat[tspull,cnames]
  Pts = dat[tspull,cts]
  
  #Start with a simple bar chart
  plot(x = Pts,
       y = bardat,
       yaxs = 'i',
       xaxs = 'i',
       #xlab = 'Date',
       ylab = 'Rainfall (mm)',
       xaxt = 'n',
       type = 'h',
       las = 1,
       cex.lab = 1.5,
       col = 'blue',
       cex.axis = 1.5,
  )
  
  midnite = Pts[which(substr(Pts,12,19) == '00:00:00')]
  noon =    Pts[which(substr(Pts,12,19) == '12:00:00')]
  
  #axis.POSIXct(1,at=midnite,labels=format(midnite,"%b-%d"),las=1,cex.axis = 1.5)
  
  abline(v = midnite,col='gray')
  abline(v = noon,col='gray',lty=2)
  
  
}
#---------------------------------------------------------------------------#


#Plot leaf wetness - discovery tree
#---------------------------------------------------------------------------#
{
  #Leaf wetness plotting parameters 
  heights = c(0,5,15,25,35,45,55)
  cnames = c('timestamp','lw0150','lw1000','lw2000','lw3000','lw4000','lw5000')
  tallness = 70
  dates = as.POSIXct(c('2017-06-01','2017-06-30'))
  main = 'Discovery Tree -  October 11th - November 11th, 2017'
  
  alldates = paste(unique(substr(discovery$timestamp,1,7)),'-01',sep='')
  #Just do 2015 onward
  alldates = alldates[-(1:15)]
  
  #Loop um
  for(i in 2:length(alldates)){
    dates = alldates[(i-1):i]
    
    dates = as.POSIXct(c('2017-10-11','2017-11-11'))
    
    jpeg(filename = paste('~/data/discovery_tree/figs/dt_lw_',dates[1],'.jpeg',sep=''),width = 30, height = 6, units = 'in',res = 300)
    plotpoly(dates = dates, heights = heights, cnames = cnames, tallness = tallness, dat = discovery, main = main)
    dev.off()
  }
  
}
#---------------------------------------------------------------------------#

#Plot leaf wetness - regrowth tree
#---------------------------------------------------------------------------#
{
  #Leaf wetness plotting parameters 
  heights = c(0,10,20,30)
  cnames = c('ts','Regrowth 5m','Regrowth 15m','Regrowth 25m')
  tallness = 35
  main = 'Adjacent Regrowth Tree'

  alldates = paste(unique(substr(regrowth$ts,1,7)),'-01',sep='')
  alldates = alldates[-(1)]
  
  #Loop um
  for(i in 2:length(alldates)){
    dates = alldates[(i-1):i]
    
    dates = as.POSIXct(c('2017-10-11','2017-11-11'))
    
    jpeg(filename = paste('~/data/discovery_tree/figs/regrowth_lw_',dates[1],'.jpeg',sep=''),width = 30, height = 8, units = 'in',res = 300)
    plotpoly(dates = dates, heights = heights, cnames = cnames, tallness = tallness, dat = regrowth,scalevals = c(445,1023),main = main)
    dev.off()
  }
  
}
#---------------------------------------------------------------------------#

#Barplot of precip
#---------------------------------------------------------------------------#
{
cnames = c('timestamp','p.precip')

#alldates = paste(unique(substr(discovery$timestamp,1,7)),'-01',sep='')
#Just do 2015 onward
#alldates = alldates[-(1:15)]
  
#Plot em all in a loop
#for(i in 2:length(alldates)){
  #dates = alldates[(i-1):i]
  
  dates = as.POSIXct(c('2017-10-11','2017-11-11'))
  
  jpeg(filename = paste('~/data/discovery_tree/figs/precip_',dates[1],'.jpeg',sep=''),width = 30, height = 4, units = 'in',res = 300)
  par(oma = c(-5,2,-5,2))
  simplebar(dates = dates,dat = discovery,cnames = cnames)
  dev.off()
#} 
  
}
#---------------------------------------------------------------------------#

#Lineplots of Tair-Tdew
#---------------------------------------------------------------------------#
{

  
alldates = paste(unique(substr(discovery$timestamp,1,7)),'-01',sep='')
#Just do 2015 onward
alldates = alldates[-(1:34)]
  
  #Plot em all in a loop
  for(i in 2:length(alldates)){
    dates = alldates[(i-1):i]
    
    tspull = head(which(substr(discovery$timestamp,1,10) == dates[1]),1):tail(which(substr(discovery$timestamp,1,10) == dates[2]),1)
    Pdat = discovery[tspull,]
    Pts = Pdat$timestamp
    
    T150 = Pdat$tair0150-Pdat$dewpt0150
    T5000 = Pdat$tair5000-Pdat$dewpt5000
    
    jpeg(filename = paste('~/data/discovery_tree/figs/Tdew_',dates[1],'.jpeg',sep=''),width = 30, height = 8, units = 'in',res = 300)
    
          plot(x = Pts, 
               y = rep(1,length(Pts)),
               ylim = range(c(T150,T5000),na.rm=T),
               yaxs = 'i',
               xaxs = 'i',
               type = 'n',
               xlab = 'Date',
               ylab = 'Tair - Tdew',
               #yaxp = c(0,80,80/5),
               xaxt = 'n',
               las = 1,
               main = paste(dates[1],'-',dates[2]),
               #cex.main = 2,
               cex.lab = 1.5,
               cex.axis = 1.5
          )
    
    #Add lines, draw x axis
    midnite = Pts[which(substr(Pts,12,19) == '00:00:00')]
    noon =    Pts[which(substr(Pts,12,19) == '12:00:00')]
    axis.POSIXct(1,at=midnite,labels=format(midnite,"%b-%d"),las=1,cex.axis = 1.5)
    
    abline(v = noon,col='black',lty=2,lwd=.5)
    abline(v = midnite,col='black',lty=1,lwd=.5)
    
    lines(x = Pts, y = T150,col = 'darkgreen',lwd = 3)
    lines(x = Pts, y = T5000, col = 'purple',lwd=3)
    
    legend(x = 'topright',fill = c('darkgreen','purple'),legend = c('1.5m height','56m height'))

    dev.off()
  } 
  
}
#---------------------------------------------------------------------------#



#Lineplots of Tair-Tdew
#---------------------------------------------------------------------------#
{
    dates = as.POSIXct(c('2017-10-11','2017-11-11'))
    
    tspull = head(which(substr(discovery$timestamp,1,10) == dates[1]),1):tail(which(substr(discovery$timestamp,1,10) == dates[2]),1)
    Pdat = discovery[tspull,]
    Pts = Pdat$timestamp
    
    T150 = Pdat$tair0150-Pdat$dewpt0150
    T5000 = Pdat$tair5000-Pdat$dewpt5000
    
    
    ggplot(Pdat)  + 
      geom_col(aes(x=timestamp, y=p.precip), fill="blue", colour="blue")+
      geom_line(aes(x=timestamp, y=tair5000-dewpt5000))
    +
      geom_text(aes(label=Rate, x=Year, y=Rate*max(df$Response)), colour="black")+
      geom_text(aes(label=Response, x=Year, y=0.95*Response), colour="black")+
      scale_y_continuous(sec.axis = sec_axis(~./max(df$Response)))
    
    
    
    
    
    jpeg(filename = paste('~/data/discovery_tree/figs/Tdew_',dates[1],'.jpeg',sep=''),width = 30, height = 8, units = 'in',res = 300)
    
    plot(x = Pts, 
         y = rep(1,length(Pts)),
         ylim = range(c(T150,T5000),na.rm=T),
         yaxs = 'i',
         xaxs = 'i',
         type = 'n',
         xlab = 'Date',
         ylab = 'Tair - Tdew',
         #yaxp = c(0,80,80/5),
         xaxt = 'n',
         las = 1,
         main = paste(dates[1],'-',dates[2]),
         #cex.main = 2,
         cex.lab = 1.5,
         cex.axis = 1.5
    )
    
    #Add lines, draw x axis
    midnite = Pts[which(substr(Pts,12,19) == '00:00:00')]
    noon =    Pts[which(substr(Pts,12,19) == '12:00:00')]
    axis.POSIXct(1,at=midnite,labels=format(midnite,"%b-%d"),las=1,cex.axis = 1.5)
    
    abline(v = noon,col='black',lty=2,lwd=.5)
    abline(v = midnite,col='black',lty=1,lwd=.5)
    
    lines(x = Pts, y = T150,col = 'darkgreen',lwd = 3)
    lines(x = Pts, y = T5000, col = 'purple',lwd=3)
    
    legend(x = 'topright',fill = c('darkgreen','purple'),legend = c('1.5m height','56m height'))
    
    dev.off()
  } 
  
}
#---------------------------------------------------------------------------#
