plotpoly_bryo = function(heights = c(0,10,20,30),tallness = 35,dat = dat,Pts = Pts,scalevals = c(260,800), main = dates,brange=brange){
  
  #Regrowth ("young" ) tree has sensors at 5, 15 and 25. So make the breaks at 0, 10, 20 and 30. Make the tree 35m tall. 
  #heights = c(0,10,20,30)
  #tallness = 35
  
  #Function to turn the above height vectors into vertices for polygon plotting
  polyhts = function(htvec){htpoly = cbind(htvec[1:length(htvec)-1],htvec[2:length(htvec)],htvec[2:length(htvec)],htvec[1:length(htvec)-1])}
  
  #Polygon heights
  htpoly = polyhts(heights)
  
  Pdat = dat
  plotcolors = colors()[c(94,614)]
  
  #Pts = 1:length(Pts)
  
  #Dummy plot
  test= plot(x = Pts, 
             y = rep(1,length(Pts)),
             ylim = c(0,tallness),
             yaxs = 'i',
             xaxs = 'i',
             type = 'n',
             xlab = '',
             ylab = 'Height (m)',
             #yaxp = c(0,80,80/5),
             #xaxt = 'n',
             las = 1,
             main = main,
             cex.main = 2,
             cex.lab = 1.5,
             cex.axis = 1.5
  )
  
  #Draw the polygon for the tree height
  polygon(x = c(rep(Pts[1],2),rep(tail(Pts,1),2)), y = c(0,tallness,tallness,0),col ='lightgray')
  
  #Now loop the days and heights, plot the data polygons!
  for(i in 1:length(Pts)-1){
    polydate = Pts[i:(i+1)]
    polyx = c(rep(polydate[1],2),rep(polydate[2],2))
    for(j in 1:nrow(htpoly)){polygon(x = polyx, y = htpoly[j,],col = plotcolors[Pdat[i,j]+1],border=NA)}
  }
  
  #Make the range lines
  abline(h = brange,lwd = 3, col = 'black')
  
  #Add lines that show where the days start 
  
  noon = Pts[match(unique(substr(ts,1,10)),substr(ts,1,10))]
  #abline(v = noon)
  #Pick it up from here
  #
  #MAKE IT ADD THE LINES ESTABLISHED ABOVE
  #
  #
  # for(j in 1:length(midnite)){
    # lines(x = rep(noon[j],2),y = c(-3,tallness),col='black',lty=1,lwd=.5)
    #if(j > 1){lines(x = rep(midnite[j],2),y = c(-3,tallness),col='black',lty=1,lwd=.5)}
  # }
  
  #Add the legend
  #xpos = quantile(noon, probs = seq(0,1,0.1))
  #color.legend(xl = xpos[9],xr = xpos[11],yb = 72, yt = 75,legend = c('dry','wet'),rect.col = plotcolors$color,cex = 2)
  
}
